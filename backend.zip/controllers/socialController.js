exports.getSocial = (req,res) =>{
	res.json({
		message:"This is the social route"
	});
}