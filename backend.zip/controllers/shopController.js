const shopModel = require('../models/shopModel');


exports.shop = (req,res) =>{
    res.send("This is the shop route");
}





